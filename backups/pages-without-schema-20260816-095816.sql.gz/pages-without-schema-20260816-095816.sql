ERROR:  column "content" does not exist
